This recipe builds a package for openzwave library
