This recipe builds a package for BACnet stack
